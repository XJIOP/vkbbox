import mc

mc.ActivateWindow(14000)
