from vkauth.vk_app_auth import VKAppAuth
